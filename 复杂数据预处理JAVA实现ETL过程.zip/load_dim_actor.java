import java.sql.*;
import java.text.*;

/**
 * @author gl526
 */
public class load_dim_actor {
    public static void main(String[] args) {
        String url1 = "jdbc:mysql://localhost:3306/sakila_19linlin?serverTimezone=UTC";
        String url2 = "jdbc:mysql://localhost:3306/sakila_dwh_19linlin?serverTimezone=UTC";
        Statement stmt1, stmt2, stmt3;
        ResultSet rs1, rs2;

        int actor_key=1,actor_id;
        java.sql.Timestamp actor_last_update;
        String actor_last_name,actor_first_name;

        Connection dbConn1, dbConn2;
        String sql1, sql2, sql3;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConn1 = DriverManager.getConnection(url1, "root", "gl526925.");
            dbConn2 = DriverManager.getConnection(url2, "root", "gl526925.");
            System.out.println("连接数据库成功");
            stmt1 = dbConn1.createStatement();
            stmt2 = dbConn2.createStatement();
            stmt3 = dbConn2.createStatement();

            sql1 = "SELECT COALESCE(\n" +
                    "           MAX(actor_last_update)\n" +
                    "       ,   '1970-01-01 00:00:00'\n" +
                    "       ) AS max_dim_actor_last_update\n" +
                    "FROM   dim_actor\n";

            rs1 = stmt2.executeQuery(sql1);

            while (rs1.next()){
                String a = rs1.getString(1);
                System.out.println(a);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.sql.Date max_dim_actor_last_update = null;
                try {
                    java.util.Date aaa = sdf.parse(a);
                    max_dim_actor_last_update = new java.sql.Date(aaa.getTime());
                } catch (Exception e) {
                    e.printStackTrace(); }

                sql2 = "SELECT\n" +
                        "  actor_id\n" +
                        ", first_name\n" +
                        ", last_name\n" +
                        ", last_update\n" +
                        "FROM actor\n" +
                        "WHERE last_update > "+max_dim_actor_last_update;

                rs2 = stmt1.executeQuery(sql2);

                while (rs2.next()){

                    int actor_id1 = rs2.getInt(1);
                    String first_name = rs2.getString(2);
                    String last_name = rs2.getString(3);
                    String last_update = rs2.getString(4);

                    actor_id = actor_id1;
                    actor_first_name = first_name;
                    actor_last_name = last_name;
                    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    actor_last_update = null;
                    try {
                        java.util.Date actor_last_update1 = sdf1.parse(last_update);
                        actor_last_update = new java.sql.Timestamp(actor_last_update1.getTime());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    //System.out.println(actor_last_update);
                    System.out.println("数据处理成功！");

                    sql3 = "INSERT INTO dim_actor " +
                            "values('"+actor_key++ +"','"+actor_last_update+"','"+actor_last_name+"','"+actor_first_name+"','"+actor_id+"')";

                    stmt3.executeUpdate(sql3);

                    System.out.println("插入数据成功！");

                }
            }
            stmt1.close();
            stmt2.close();
            stmt3.close();
            dbConn1.close();
            dbConn2.close();
        }
        catch (Exception e) {
            e.printStackTrace(); }
    }
}
