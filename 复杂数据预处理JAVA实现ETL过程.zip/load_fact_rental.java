import com.mysql.cj.x.protobuf.Mysqlx;

import java.math.BigDecimal;
import java.sql.*;
import java.text.*;

public class load_fact_rental {
    public static void main(String[] args) {
        String url1 = "jdbc:mysql://localhost:3306/sakila_19linlin?serverTimezone=UTC";
        String url2 = "jdbc:mysql://localhost:3306/sakila_dwh_19linlin?serverTimezone=UTC";
        Connection dbConn1, dbConn2;
        Statement stmt1,stmt2,stmt3,stmt4,stmt5,stmt6,stmt7,stmt8,stmt9,stmt10;
        ResultSet rs1,rs2,rs3,rs4,rs5,rs6,rs7,rs8,rs9;
        String sql1, sql2, sql3,sql4,sql5,sql6,sql7,sql8,sql9,sql10;

        int customer_key,staff_key,film_key,store_key,count_rentals = 1,rental_id,return_date_key1,count_returns;
        Integer rental_duration = null;
        int k =1;
        long rental_duration1;
        String rental_date_key,return_date_key,rental_time_key,return_time_key;
        java.sql.Timestamp rental_last_update = null;
        BigDecimal rental_amount;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConn1 = DriverManager.getConnection(url1, "root", "gl526925.");
            dbConn2 = DriverManager.getConnection(url2, "root", "gl526925.");
            System.out.println("连接数据库成功");

            stmt1 = dbConn2.createStatement();
            stmt2 = dbConn1.createStatement();
            stmt3 = dbConn1.createStatement();
            stmt4 = dbConn2.createStatement();
            stmt5 = dbConn1.createStatement();
            stmt6 = dbConn2.createStatement();
            stmt7 = dbConn2.createStatement();
            stmt8 = dbConn2.createStatement();
            stmt9 = dbConn2.createStatement();

            //max_fact_rental_last_update
            sql1 = "SELECT " +
                    "coalesce(" +
                    "max(rental_last_update)," +
                    "'1970-01-01') " +
                    "FROM fact_rental";
            rs1 = stmt1.executeQuery(sql1);
            while (rs1.next()){
                //java.sql.Timestamp max_fact_rental_last_update = rs1.getTimestamp(1);
                String a = rs1.getString(1);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                java.sql.Date max_fact_rental_last_update = null;
                try {
                    java.util.Date aaa = sdf.parse(a);
                    max_fact_rental_last_update = new java.sql.Date(aaa.getTime());
                } catch (Exception e) {
                    e.printStackTrace(); }
                System.out.println(max_fact_rental_last_update);

                sql2 = "SELECT\n" +
                        "  rental_id\n" +
                        ", rental_date\n" +
                        ", return_date\n" +
                        ", inventory_id\n" +
                        ", customer_id\n" +
                        ", staff_id\n" +
                        ",last_update\n" +
                        "FROM rental\n" +
                        "WHERE last_update > "+ max_fact_rental_last_update;
                rs2 =  stmt2.executeQuery(sql2);
                System.out.println("ok");
                while (rs2.next()) {
                    rental_id = rs2.getInt(1);
                    String rental_datetime1 = rs2.getString(2);
                    String return_datetime1 = rs2.getString(3);
                    int inventory_id = rs2.getInt(4);
                    int customer_id = rs2.getInt(5);
                    int staff_id = rs2.getInt(6);
                    String last_update1 = rs2.getString(7);

                    if (return_datetime1 != null ) {

                        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        java.sql.Timestamp rental_datetime = null, return_datetime = null, rental_time = null,return_time = null;
                        try {
                            java.util.Date b = sdf1.parse(rental_datetime1);
                            java.util.Date bb = sdf1.parse(return_datetime1);
                            java.util.Date bbb = sdf1.parse(last_update1);
                            rental_datetime = new java.sql.Timestamp(b.getTime());
                            return_datetime = new java.sql.Timestamp(bb.getTime());
                            rental_last_update = new java.sql.Timestamp(bbb.getTime());
                            int milisecs = 1000;
                            long rental_duration_milisecs;
                            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            try {
                                java.util.Date d1 = sdf2.parse(rental_datetime1);
                                java.util.Date d2 = sdf2.parse(return_datetime1);
                                rental_duration_milisecs = d2.getTime() - d1.getTime();
                                rental_duration1 =rental_duration_milisecs / milisecs;
                                rental_duration = (int)rental_duration1;
                            }catch (Exception e){
                                e.printStackTrace(); }
                        } catch (Exception e) {
                            e.printStackTrace(); }
                        DateFormat df = new SimpleDateFormat("yyyyMMdd");
                        DateFormat df1 = new SimpleDateFormat("HHmmss");
                        rental_date_key = df.format(rental_datetime);
                        rental_time_key = df1.format(rental_datetime);
                        return_date_key = df.format(return_datetime);
                        return_time_key = df1.format(return_datetime);
                        count_returns = 1;
                        return_date_key1 = Integer.parseInt(return_date_key);
                        sql3 =  "select film_id , store_id " +
                                "from inventory " +
                                "where inventory_id = "+inventory_id;
                        rs3 = stmt3.executeQuery(sql3);
                        while (rs3.next()){
                            int film_id = rs3.getInt(1);
                            int store_id = rs3.getInt(2);

                            sql4 = "select film_key from dim_film " +
                                    "where film_id = "+film_id;
                            rs4 = stmt4.executeQuery(sql4);
                            while (rs4.next()){
                                film_key = rs4.getInt(1);

                                sql5 = "select amount from payment " +
                                        "where rental_id = "+rental_id;
                                rs5 = stmt5.executeQuery(sql5);
                                while (rs5.next()){
                                    BigDecimal amount = rs5.getBigDecimal(1);
                                    sql6 = "select customer_key from dim_customer " +
                                            "where customer_id = "+customer_id;
                                    rs6 = stmt6.executeQuery(sql6);
                                    while (rs6.next()){
                                        customer_key = rs6.getInt(1);
                                        sql7 = "select staff_key from dim_staff " +
                                                "where staff_id ="+staff_id;
                                        rs7 = stmt7.executeQuery(sql7);
                                        while (rs7.next()){
                                            staff_key = rs7.getInt(1);
                                            sql8 = "select store_key from dim_store " +
                                                    "where store_id = "+store_id;
                                            rs8 = stmt8.executeQuery(sql8);
                                            while (rs8.next()){
                                                store_key = rs8.getInt(1);
                                                return_date_key = Integer.toString(return_date_key1);
                                                rental_amount = amount;
                                                sql9 = "INSERT INTO fact_rental " +
                                                        "values ('"+customer_key+"','"+staff_key+"','"+film_key+"','"+store_key+
                                                        "','"+rental_date_key+"','"+return_date_key+"','"+rental_time_key+"','"+count_returns+
                                                        "','"+count_rentals+"','"+rental_duration+"','"+rental_last_update+"','"+rental_id+"','"+
                                                        rental_amount+"')";
                                                stmt9.executeUpdate(sql9);

                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                    else{
                        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        java.sql.Timestamp rental_datetime = null, return_datetime = null,rental_time = null,return_time = null;
                        try {
                            java.util.Date b = sdf1.parse(rental_datetime1);
                            //java.util.Date bb = sdf1.parse(return_datetime1);
                            java.util.Date bbb = sdf1.parse(last_update1);
                            rental_datetime = new java.sql.Timestamp(b.getTime());
                            //return_datetime = new java.sql.Timestamp(bb.getTime());
                            rental_last_update = new java.sql.Timestamp(bbb.getTime());
                        } catch (Exception e) {
                            e.printStackTrace(); }
                        DateFormat df = new SimpleDateFormat("yyyyMMdd");
                        DateFormat df1 = new SimpleDateFormat("HHmmss");
                        rental_date_key = df.format(rental_datetime);
                        rental_time_key = df1.format(rental_datetime);
                        return_date_key = "0";
                        return_time_key = "0";
                        count_returns = 0;
                        return_date_key1 = 0;
                        rental_duration = null;
                        sql3 =  "select film_id , store_id " +
                                "from inventory " +
                                "where inventory_id = "+inventory_id;
                        rs3 = stmt3.executeQuery(sql3);
                        while (rs3.next()){
                            int film_id = rs3.getInt(1);
                            int store_id = rs3.getInt(2);

                            sql4 = "select film_key from dim_film " +
                                    "where film_id = "+film_id;
                            rs4 = stmt4.executeQuery(sql4);
                            while (rs4.next()){
                                film_key = rs4.getInt(1);

                                sql5 = "select amount from payment " +
                                        "where rental_id = "+rental_id;
                                rs5 = stmt5.executeQuery(sql5);
                                while (rs5.next()){
                                    BigDecimal amount = rs5.getBigDecimal(1);
                                    sql6 = "select customer_key from dim_customer " +
                                            "where customer_id = "+customer_id;
                                    rs6 = stmt6.executeQuery(sql6);
                                    while (rs6.next()){
                                        customer_key = rs6.getInt(1);
                                        sql7 = "select staff_key from dim_staff " +
                                                "where staff_id ="+staff_id;
                                        rs7 = stmt7.executeQuery(sql7);
                                        while (rs7.next()){
                                            staff_key = rs7.getInt(1);
                                            sql8 = "select store_key from dim_store " +
                                                    "where store_id = "+store_id;
                                            rs8 = stmt8.executeQuery(sql8);
                                            while (rs8.next()){
                                                store_key = rs8.getInt(1);
                                                return_date_key = Integer.toString(return_date_key1);
                                                rental_amount = amount;
                                                sql9 = "INSERT INTO fact_rental " +
                                                        "values ('"+customer_key+"','"+staff_key+"','"+film_key+"','"+store_key+
                                                        "','"+rental_date_key+"','"+return_date_key+"','"+rental_time_key+"','"+count_returns+
                                                        "','"+count_rentals+"',"+rental_duration+",'"+rental_last_update+"','"+rental_id+"','"+
                                                        rental_amount+"')";
                                                stmt9.executeUpdate(sql9);

                                            }
                                        }
                                    }

                                }
                            }
                        }
                    }
                    int g = k++;
                    System.out.println("第"+g+"条数据成功！");
                }
            }

        }catch (Exception e) {
            e.printStackTrace(); }
    }
}
