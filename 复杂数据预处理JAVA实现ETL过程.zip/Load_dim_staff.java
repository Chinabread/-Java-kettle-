import java.sql. *;
import java.text.*;


/**
 * @author gl526
 */
public class Load_dim_staff{
    public static void main(String[] args) {
        String url1 = "jdbc:mysql://localhost:3306/sakila_dwh_19linlin?serverTimezone=UTC" ;
        String url2 = "jdbc:mysql://localhost:3306/sakila_19linlin?serverTimezone=UTC";
        Statement stmt1,stmt2,stmt3,stmt4;
        ResultSet rs1,rs2;

        //dim_staff数据类型
        String staff_first_name,staff_last_name,staff_active;
        java.sql.Timestamp staff_valid_from,staff_valid_through,staff_last_update;
        int staff_key = 1,staff_store_id,staff_id,staff_version_number;




        Connection dbConn1,dbConn2;
        String sql1,sql2,sql3,sql4,sql5;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConn1 = DriverManager.getConnection(url1, "root", "gl526925.");
            dbConn2 = DriverManager.getConnection(url2, "root", "gl526925.");
            System.out.println("连接数据库成功");
            stmt1 = dbConn1.createStatement();
            stmt2 = dbConn2.createStatement();
            stmt3 = dbConn1.createStatement();
            stmt4 = dbConn2.createStatement();

            sql1 = "select COALESCE " +
                    "(max(staff_last_update),'1970-01-01 00:00:00')" +
                    "max_dim_staff_last_update from dim_staff";

            rs1 = stmt1.executeQuery(sql1);
            while(rs1.next()) {
                String a = rs1.getString(1);
                System.out.println(a);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.sql.Date max_dim_staff_last_update= null;
                try{
                    java.util.Date aaa = sdf.parse(a);
                    max_dim_staff_last_update = new java.sql.Date(aaa.getTime());
                }catch (Exception e){
                    e.printStackTrace();
                }

                sql2 = "SELECT" +
                        "  staff_id" +
                        ", first_name" +
                        ", last_name" +
                        ", address_id" +
                        ", picture" +
                        ", email" +
                        ", store_id" +
                        ", active" +
                        ", username" +
                        ", password" +
                        ", last_update from `staff`" +
                        "WHERE last_update > "+ max_dim_staff_last_update;

                //stmt2.executeQuery(sql2);

                rs2 = stmt2.executeQuery(sql2);
                while (rs2.next()) {
                    int staff_id1 = rs2.getInt(1);
                    String first_name = rs2.getString(2);
                    String last_name = rs2.getString(3);
                    int address_id = rs2.getInt(4);
                    Blob picture = rs2.getBlob(5);
                    String email = rs2.getString(6);
                    int store_id = rs2.getInt(7);
                    int active = rs2.getInt(8);
                    String username = rs2.getString(9);
                    String password = rs2.getString(10);
                    String last_update = rs2.getString(11);



                    SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    staff_last_update = null;
                    try {
                        java.util.Date staff_last_update2 = sdf2.parse(last_update);
                        staff_last_update = new java.sql.Timestamp(staff_last_update2.getTime());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    staff_first_name = first_name;
                    staff_last_name = last_name;
                    staff_id = staff_id1;
                    staff_store_id = store_id;
                    staff_version_number = 1;


                    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
                    staff_valid_from = null;
                    staff_valid_through = null;
                    try {
                        java.util.Date staff_valid_from1 = sdf1.parse("1900-01-01");
                        java.util.Date staff_valid_through1 = sdf1.parse("2200-01-01");
                        staff_valid_from = new java.sql.Timestamp(staff_valid_from1.getTime());
                        staff_valid_through = new java.sql.Timestamp(staff_valid_through1.getTime());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    if (active == 1) {
                        staff_active = "YES";
                    } else {
                        staff_active = "NO";
                    }

                    System.out.println("处理数据成功！");

                    //sql4 = "alter table dim_staff alter column staff_key identity(1,1) primary key ";
                    //sql4 = "alter table dim_staff add staff_key int identity not null primary key;";
                    sql5 = "INSERT INTO dim_staff " +
                            "VALUES('" + staff_key++ + "','" + staff_last_update + "','" + staff_first_name + "','" + staff_last_name + "','"
                            + staff_id + "','" + staff_store_id + "','" + staff_version_number + "','" + staff_valid_from + "','"
                            + staff_valid_through + "','" + staff_active + "')";

                    stmt3.executeUpdate(sql5);

                    System.out.println(sql5);
                }

            }
            sql3 = "ALTER TABLE staff DROP column picture";
            stmt4.executeUpdate(sql3);
            System.out.println("删除picture列成功！");

            stmt1.close();
            stmt2.close();
            stmt3.close();
            stmt4.close();
            dbConn1.close();
            dbConn2.close();
        }
        catch (Exception e){
            e.printStackTrace(); }
    }
}