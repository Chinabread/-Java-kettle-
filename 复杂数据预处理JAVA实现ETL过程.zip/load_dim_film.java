import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import com.sun.xml.internal.ws.runtime.config.TubelineFeatureReader;

import javax.smartcardio.CardTerminal;
import javax.xml.soap.Text;
import java.math.BigDecimal;
import java.sql.*;
import java.text.*;
import java.time.Year;
import java.util.Arrays;

import static java.math.BigDecimal.ROUND_HALF_UP;


/**
 * @author gl526
 */
public class load_dim_film {
    public static void main(String[] args) {
        String url1 = "jdbc:mysql://localhost:3306/sakila_19linlin?serverTimezone=UTC";
        String url2 = "jdbc:mysql://localhost:3306/sakila_dwh_19linlin?serverTimezone=UTC";
        Statement stmt1,stmt2,stmt3,stmt4,stmt5,stmt6,stmt7,stmt8,stmt9,stmt10;
        ResultSet rs1,rs2,rs3,rs4,rs5,rs6,rs7,rs8,rs9;

        int film_key=1,film_id,film_release_year,film_rental_duration,film_duration;
        java.sql.Timestamp film_last_update;
        BigDecimal film_rental_rate,film_replacement_cost,actor_weighting_factor;
        String film_title,film_description,film_language,film_original_language,film_rating_code,
                film_rating_text,film_has_trailers,film_has_commentaries,film_has_deleted_scenes,
                film_has_behind_the_scenes,film_in_category_action,film_in_category_animation,
                film_in_category_children,film_in_category_classics,film_in_category_comedy,film_in_category_documentary,
                film_in_category_drama,film_in_category_family,film_in_category_foreign,film_in_category_games,
                film_in_category_horror,film_in_category_music,film_in_category_new,film_in_category_scifi,
                film_in_category_sports,film_in_category_travel;

        Connection dbConn1, dbConn2;
        String sql1, sql2, sql3,sql4,sql5,sql6,sql7,sql8,sql9,sql10;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConn1 = DriverManager.getConnection(url1, "root", "gl526925.");
            dbConn2 = DriverManager.getConnection(url2, "root", "gl526925.");
            System.out.println("连接数据库成功");
            stmt1 = dbConn1.createStatement();
            stmt2 = dbConn2.createStatement();
            stmt3 = dbConn1.createStatement();
            stmt4 = dbConn1.createStatement();
            stmt5 = dbConn1.createStatement();
            stmt6 = dbConn2.createStatement();
            stmt7 = dbConn1.createStatement();
            stmt8 = dbConn1.createStatement();
            stmt9 = dbConn2.createStatement();
            stmt10 = dbConn2.createStatement();


            //max_dim_film_last_update
            sql1 = "SELECT COALESCE(" +
                    "    MAX(film_last_update)" +
                    "     ,   '1970-01-01 00:00:00'" +
                    "  ) AS max_dim_film_last_update" +
                    " FROM   dim_film";

            rs1 = stmt2.executeQuery(sql1);
            while (rs1.next()){



                String a = rs1.getString(1);
                System.out.println(a);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.sql.Date max_dim_film_last_update = null;
                try {
                    java.util.Date aaa = sdf.parse(a);
                    max_dim_film_last_update = new java.sql.Date(aaa.getTime());
                } catch (Exception e) {
                    e.printStackTrace(); }
                System.out.println("max_dim_film_last_update成功");

                //Film
                sql2 = "SELECT" +
                        "  film_id" +
                        ", title" +
                        ", description\n" +
                        ", CAST(release_year AS UNSIGNED) release_year" +
                        ", language_id" +
                        ", original_language_id" +
                        ", rental_duration" +
                        ", rental_rate" +
                        ", length " +
                        ", replacement_cost" +
                        ", rating" +
                        ", special_features" +
                        ", last_update " +
                        "FROM film " +
                        "WHERE last_update > "+max_dim_film_last_update;

                rs2 = stmt1.executeQuery(sql2);

                while (rs2.next()){
                    int film_id1 = rs2.getInt(1);
                    String title = rs2.getString(2);
                    String description = rs2.getString(3);
                    int release_year = rs2.getInt(4);
                    int language_id = rs2.getInt(5);
                    int original_language_id = rs2.getInt(6);
                    int rental_duration = rs2.getInt(7);
                    BigDecimal rental_rate = rs2.getBigDecimal(8);
                    int length = rs2.getInt(9);
                    BigDecimal replacement_cost = rs2.getBigDecimal(10);
                    String rating = rs2.getString(11);
                    String special_features = rs2.getString(12);
                    String last_update = rs2.getString(13);

                    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    film_last_update = null;
                    try {
                        java.util.Date film_last_update1 = sdf1.parse(last_update);
                        film_last_update = new java.sql.Timestamp(film_last_update1.getTime());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    System.out.println("Film成功");

                    //Lookup Language
                    sql3 = "select name from language where language_id = "+language_id;
                    rs3 = stmt3.executeQuery(sql3);

                    while (rs3.next()){
                        String language = rs3.getString(1);
                        System.out.println("look language成功");

                            //Lookup original_Language
                            String original_language = null;
                            if(original_language_id == 0) {
                               original_language = "Not Applicable";
                            }
                            System.out.println("lookup origunal_language 成功");

                            //rating值映射
                        String rating_text = null;
                            /*if (rating.equals("G")) {
                                rating_text = "General Audiences";
                            }
                            if (rating.equals("PG")){
                                rating_text = "Parental Guidance Suggested";
                            }
                            if (rating.equals("PG-13")){
                                rating_text = "Parents Strongly Cautioned";
                            }
                            if (rating.equals("R")){
                                rating_text = "Restricted";
                            }
                            if (rating.equals("NC-17")){
                                rating_text = "No One Under 17 Admitted ";
                            }
                            else{
                                rating_text = "Not Yet Rated";
                            }*/
                            switch (rating){
                                case "G":{
                                    rating_text = "General Audiences";
                                    break;
                                }
                                case "PG":{
                                    rating_text = "Parental Guidance Suggested";
                                    break;
                                }
                                case "PG-13": {
                                    rating_text = "Parents Strongly Cautioned";
                                    break;
                                }
                                case "R":{
                                    rating_text = "Restricted";
                                    break;
                                }
                                case "NC-17":{
                                    rating_text = "No One Under 17 Admitted ";
                                    break;
                                }
                                default:{
                                    rating_text = "Not Yet Rated";
                                }
                            }
                            System.out.println("rating值映射成功");

                            //Normalize Special Features
                            String []  special_feature = special_features.split(",");
                            System.out.println("Normalize Special Features 成功");

                            //Denormalize Special Features to 'Yes' Columns

                            String tmp_has_trailers,tmp_has_commentaries,tmp_has_deleted_scenes,tmp_has_behind_the_scenes;
                            if (Arrays.asList(special_feature).contains("Trailers")){
                                tmp_has_trailers ="Yes";
                            }
                            else{
                                tmp_has_trailers = null;
                            }
                            if (Arrays.asList(special_feature).contains("Commentaries")){
                                tmp_has_commentaries = "Yes";
                            }
                            else{
                                tmp_has_commentaries = null ;
                            }
                            if (Arrays.asList(special_feature).contains("Deleted Scenes")){
                                tmp_has_deleted_scenes = "Yes";
                            }
                            else{
                                tmp_has_deleted_scenes = null ;
                            }
                            if (Arrays.asList(special_feature).contains("Behind the Scenes")){
                                tmp_has_behind_the_scenes = "Yes";
                            }
                            else{
                                tmp_has_behind_the_scenes = null ;
                            }
                            System.out.println("YES列转行成功");

                            //Set Empty Special Feature Columns  to 'No'
                            //NVL(E1, E2)的功能为：如果E1为NULL，则函数返回E2，否则返回E1本身
                            String has_behind_the_scenes,has_commentaries,has_deleted_scenes,has_trailers;

                            if (tmp_has_behind_the_scenes != null ){
                                has_behind_the_scenes = tmp_has_behind_the_scenes;
                            }
                            else{
                                has_behind_the_scenes = "No";
                            }
                            if (tmp_has_commentaries != null){
                                has_commentaries = tmp_has_commentaries;
                            }
                            else{
                                has_commentaries = "No";
                            }
                            if (tmp_has_deleted_scenes != null){
                                has_deleted_scenes = tmp_has_deleted_scenes;
                            }
                            else{
                                has_deleted_scenes = "No";
                            }
                            if (tmp_has_trailers != null){
                                has_trailers = tmp_has_trailers;
                            }
                            else {
                                has_trailers = "No";
                            }
                            System.out.println("NVL函数运行成功！");

                            sql4 = "SELECT category_id " +
                                    "FROM   film_category " +
                                    "WHERE  film_id = "+film_id1;

                            rs4 = stmt4.executeQuery(sql4);

                            while (rs4.next()){
                               int  category_id = rs4.getInt(1);

                                sql5 = "select name from category where category_id = "+category_id;
                                rs5 = stmt5.executeQuery(sql5);
                                while (rs5.next()) {
                                    String category = rs5.getString(1);
                                    //System.out.println(category);

                                    System.out.println("lookup category 成功！");
                                    String  tmp_is_category_action,tmp_is_category_animation,tmp_is_category_children,tmp_is_category_classics, tmp_is_category_comedy,
                                            tmp_is_category_documentary,tmp_is_category_drama,tmp_is_category_family,tmp_is_category_foreign,tmp_is_category_games,
                                            tmp_is_category_horror,tmp_is_category_music,tmp_is_category_new,tmp_is_category_sci_fi,tmp_is_category_sports,tmp_is_category_travel;
                                    if(category.equals("Action")){
                                        tmp_is_category_action = "Yes";
                                    }
                                    else{
                                        tmp_is_category_action = null;
                                    }
                                    if(category.equals("Animation")){
                                        tmp_is_category_animation = "Yes";
                                    }
                                    else{
                                        tmp_is_category_animation = null;
                                    }
                                    if(category.equals("Children")){
                                        tmp_is_category_children = "Yes";
                                    }
                                    else{
                                        tmp_is_category_children = null;
                                    }
                                    if (category.equals("Classics")){
                                        tmp_is_category_classics = "Yes";
                                    }
                                    else {
                                        tmp_is_category_classics = null;
                                    }
                                    if (category.equals("Comedy")){
                                        tmp_is_category_comedy = "Yes";
                                    }
                                    else{
                                        tmp_is_category_comedy = null;
                                    }
                                    if (category.equals("Documentary")){
                                        tmp_is_category_documentary = "Yes";
                                    }
                                    else{
                                        tmp_is_category_documentary = null;
                                    }
                                    if (category.equals("Drama")){
                                        tmp_is_category_drama = "Yes";
                                    }
                                    else{
                                        tmp_is_category_drama = null;
                                    }
                                    if (category.equals( "Family")){
                                        tmp_is_category_family = "Yes";
                                    }
                                    else {
                                        tmp_is_category_family = null;
                                    }
                                    if (category.equals("Foreign")){
                                        tmp_is_category_foreign = "Yes";
                                    }
                                    else{
                                        tmp_is_category_foreign = null;
                                    }
                                    if (category.equals("Games")){
                                        tmp_is_category_games = "Yes";
                                    }
                                    else {
                                        tmp_is_category_games = null;
                                    }
                                    if (category.equals("Horror")){
                                        tmp_is_category_horror = "Yes";
                                    }
                                    else {
                                        tmp_is_category_horror = null;
                                    }
                                    if (category.equals( "Music")){
                                        tmp_is_category_music = "Yes";
                                    }
                                    else{
                                        tmp_is_category_music = null;
                                    }
                                    if (category.equals("New")){
                                        tmp_is_category_new = "Yes";
                                    }
                                    else{
                                        tmp_is_category_new = null;
                                    }
                                    if (category.equals("Sci-Fi")){
                                        tmp_is_category_sci_fi = "Yes";
                                    }
                                    else {
                                        tmp_is_category_sci_fi = null;
                                    }
                                    if (category.equals("Sports")){
                                        tmp_is_category_sports = "Yes";
                                    }
                                    else {
                                        tmp_is_category_sports = null;
                                    }
                                    if (category.equals("Travel")){
                                        tmp_is_category_travel = "Yes";
                                    }
                                    else{
                                        tmp_is_category_travel = null;
                                    }

                                    //Set Empty Special Feature Columns  to 'No'
                                    //NVL(E1, E2)的功能为：如果E1为NULL，则函数返回E2，否则返回E1本身
                                    if (tmp_is_category_action != null){
                                        film_in_category_action = tmp_is_category_action;
                                    }
                                    else{
                                        film_in_category_action = "No";
                                    }
                                    if (tmp_is_category_animation != null){
                                        film_in_category_animation = tmp_is_category_animation;
                                    }
                                    else {
                                        film_in_category_animation = "No";
                                    }
                                    if (tmp_is_category_children != null){
                                        film_in_category_children = tmp_is_category_children;
                                    }
                                    else {
                                        film_in_category_children = "No";
                                    }
                                    if(tmp_is_category_classics != null){
                                        film_in_category_classics = tmp_is_category_classics;
                                    }
                                    else{
                                        film_in_category_classics = "No";
                                    }
                                    if (tmp_is_category_comedy != null){
                                        film_in_category_comedy = tmp_is_category_comedy;
                                    }
                                    else{
                                        film_in_category_comedy = "No";
                                    }
                                    if (tmp_is_category_documentary != null){
                                        film_in_category_documentary = tmp_is_category_documentary;
                                    }
                                    else{
                                        film_in_category_documentary = "No";
                                    }
                                    if (tmp_is_category_drama != null ){
                                        film_in_category_drama = tmp_is_category_drama;
                                    }
                                    else{
                                        film_in_category_drama = "No";
                                    }
                                    if (tmp_is_category_family != null){
                                        film_in_category_family = tmp_is_category_family;
                                    }
                                    else{
                                        film_in_category_family = "No";
                                    }
                                    if (tmp_is_category_foreign != null){
                                        film_in_category_foreign = tmp_is_category_foreign;
                                    }
                                    else{
                                        film_in_category_foreign = "No";
                                    }
                                    if (tmp_is_category_games != null) {
                                        film_in_category_games = tmp_is_category_games;
                                    }
                                    else{
                                        film_in_category_games = "No";
                                    }
                                    if (tmp_is_category_horror != null){
                                        film_in_category_horror = tmp_is_category_horror;
                                    }
                                    else{
                                        film_in_category_horror = "No";
                                    }
                                    if (tmp_is_category_music != null){
                                        film_in_category_music = tmp_is_category_music;
                                    }
                                    else{
                                        film_in_category_music = "No";
                                    }
                                    if (tmp_is_category_new != null){
                                        film_in_category_new = tmp_is_category_new;
                                    }
                                    else{
                                        film_in_category_new ="No";
                                    }
                                    if (tmp_is_category_sci_fi != null){
                                        film_in_category_scifi = tmp_is_category_sci_fi;
                                    }
                                    else{
                                        film_in_category_scifi = "No";
                                    }
                                    if (tmp_is_category_sports != null){
                                        film_in_category_sports = tmp_is_category_sports;
                                    }
                                    else {
                                        film_in_category_sports = "No";
                                    }
                                    if (tmp_is_category_travel != null){
                                        film_in_category_travel = tmp_is_category_travel;
                                    }
                                    else{
                                        film_in_category_travel = "No";
                                    }

                                    System.out.println("数据处理完成！");

                                    film_title = title;
                                    film_description = description;
                                    film_release_year = release_year;
                                    film_language = language;
                                    film_original_language = original_language;
                                    film_rental_duration = rental_duration;
                                    film_rental_rate = rental_rate;
                                    film_replacement_cost = replacement_cost;
                                    film_rating_code = rating;
                                    film_rating_text =rating_text;
                                    film_has_behind_the_scenes =has_behind_the_scenes;
                                    film_has_commentaries = has_commentaries;
                                    film_has_deleted_scenes = has_deleted_scenes;
                                    film_has_trailers = has_trailers;
                                    film_duration = length;
                                    film_id = film_id1;



                                    sql6 = "INSERT INTO dim_film" +
                                            " values ('"+film_key +"','"+film_last_update+"','"+film_title+"','"+film_description+"','"+film_release_year+
                                            "','"+film_language+"','"+film_original_language+"','"+film_rental_duration+"','"+film_rental_rate+"','"+film_duration+
                                            "','"+film_replacement_cost+"','"+film_rating_code+"','"+film_rating_text+"','"+film_has_trailers+"','"+film_has_commentaries+
                                            "','"+film_has_deleted_scenes+"','"+film_has_behind_the_scenes+"','"+film_in_category_action+"','"+film_in_category_animation+
                                            "','"+film_in_category_children+"','"+film_in_category_classics+"','"+film_in_category_comedy+"','"+film_in_category_documentary+
                                            "','"+film_in_category_drama+"','"+film_in_category_family+"','"+film_in_category_foreign+"','"+film_in_category_games+"','"+
                                            film_in_category_horror+"','"+film_in_category_music+"','"+film_in_category_new+"','"+film_in_category_scifi+"','"+film_in_category_sports+
                                            "','"+film_in_category_travel+"','"+film_id+"')";

                                    stmt6.executeUpdate(sql6);


                                    System.out.println("插入dim_film表成功！");

                                    sql7 = "select actor_id " +
                                            "from   film_actor " +
                                            "where  film_id = "+ film_id ;

                                    rs7 = stmt7.executeQuery(sql7);

                                    while (rs7.next()){
                                        int actor_id = rs7.getInt(1);

                                        sql8 = "select count(actor_id) " +
                                                "from film_actor " +
                                                "where film_id = "+film_key;

                                        rs8 = stmt8.executeQuery(sql8);

                                        while (rs8.next()){
                                            BigDecimal count_actors = rs8.getBigDecimal(1);

                                            BigDecimal one = new BigDecimal(1);

                                            actor_weighting_factor = one.divide(count_actors,5,ROUND_HALF_UP);
                                            //System.out.println(actor_weighting_factor);

                                            sql9 = "select actor_key" +
                                                    " from dim_actor " +
                                                    "where actor_id = "+actor_id;

                                            rs9 = stmt9.executeQuery(sql9);

                                            while (rs9.next()){

                                                int actor_key = rs9.getInt(1);

                                                sql10 = "INSERT INTO dim_film_actor_bridge " +
                                                        " values('"+film_key+"','"+actor_key+"','"+actor_weighting_factor+"')";

                                                stmt10.executeUpdate(sql10);
                                                System.out.println("插入dim_film_actor_bridge表成功！");



                                            }
                                        }


                                    }
                                    film_key++;
                                }
                            }

                    }

                }
            }



        }catch (Exception e) {
            e.printStackTrace(); }

    }
}