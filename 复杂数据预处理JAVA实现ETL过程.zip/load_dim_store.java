import java.sql.*;
import java.text.*;

/**
 * @author gl526
 */
public class load_dim_store {
    public static void main(String[] args) {
        String url1 = "jdbc:mysql://localhost:3306/sakila_19linlin?serverTimezone=UTC";
        String url2 = "jdbc:mysql://localhost:3306/sakila_dwh_19linlin?serverTimezone=UTC";
        Statement stmt1, stmt2, stmt3, stmt4, stmt5,stmt6,stmt7;
        ResultSet rs1, rs2, rs3, rs4, rs5,rs6;

        //dim_store表数据类型定义
        int store_key = 1, store_id, store_manager_staff_id, store_version_number = 1;
        String store_addrees, store_district, store_postal_code, store_phone_number, store_city;
        String store_country, store_manager_first_name, store_manager_last_name;
        java.sql.Timestamp store_last_update, store_valid_from, store_valid_through;

        Connection dbConn1, dbConn2;
        String sql1, sql2, sql3, sql4, sql5, sql6,sql7;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            dbConn1 = DriverManager.getConnection(url1, "root", "gl526925.");
            dbConn2 = DriverManager.getConnection(url2, "root", "gl526925.");
            System.out.println("连接数据库成功");
            stmt1 = dbConn1.createStatement();
            stmt2 = dbConn2.createStatement();
            stmt3 = dbConn1.createStatement();
            stmt4 = dbConn1.createStatement();
            stmt5 = dbConn1.createStatement();
            stmt6 = dbConn1.createStatement();
            stmt7 = dbConn2.createStatement();

            sql1 = "SELECT COALESCE(\n" +
                    " MAX(store_last_update)\n" +
                    " ,'1970-01-01 00:00:00'\n" +
                    " ) max_dim_store_last_update\n" +
                    "FROM dim_store\n";

            rs1 = stmt2.executeQuery(sql1);

            while (rs1.next()){
                String a = rs1.getString(1);
                System.out.println(a);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                java.sql.Date max_dim_store_last_update = null;
                try {
                    java.util.Date aaa = sdf.parse(a);
                    max_dim_store_last_update = new java.sql.Date(aaa.getTime());
                } catch (Exception e) {
                    e.printStackTrace();
                }

                sql2 = "SELECT store_id\n" +
                        ",manager_staff_id\n" +
                        ",address_id\n" +
                        ",last_update\n" +
                        "FROM store\n" +
                        "WHERE last_update >"+max_dim_store_last_update;

                rs2 = stmt1.executeQuery(sql2);

                while (rs2.next()){
                    int store_id1 = rs2.getInt(1);
                    int manager_staff_id = rs2.getInt(2);
                    int address_id = rs2.getInt(3);
                    String last_update = rs2.getString(4);

                    SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    store_last_update = null;
                    try {
                        java.util.Date store_last_update1 = sdf1.parse(last_update);
                        store_last_update = new java.sql.Timestamp(store_last_update1.getTime());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    sql3 = "SELECT\n" +
                            "  address\n" +
                            ", address2\n" +
                            ", district\n" +
                            ", city_id\n" +
                            ", postal_code\n" +
                            ", phone\n" +
                            "FROM address\n" +
                            "WHERE address_id = "+address_id;

                    rs3 = stmt3.executeQuery(sql3);
                    while (rs3.next()){
                        String address = rs3.getString(1);
                        String address2 = rs3.getString(2);
                        String district = rs3.getString(3);
                        int city_id = rs3.getInt(4);
                        String postal_code = rs3.getString(5);
                        String phone = rs3.getString(6);

                        sql4 = "SELECT city,country_id from city where city_id = "+city_id;

                        rs4 = stmt4.executeQuery(sql4);

                        while (rs4.next()){
                            String city = rs4.getString(1);
                            int country_id = rs4.getInt(2);

                            sql5 = "select country from country where country_id = "+country_id;

                            rs5 = stmt5.executeQuery(sql5);

                            while (rs5.next()){
                                String country = rs5.getString(1);

                                if (address2 != null){
                                    address = address +' '+address2;
                                }
                                sql6 = "select first_name,last_name from staff" +
                                        " where staff_id =" + manager_staff_id;
                                rs6 = stmt6.executeQuery(sql6);
                                while (rs6.next()){
                                    String first_name = rs6.getString(1);
                                    String last_name = rs6.getString(2);

                                    store_id = store_id1;
                                    store_addrees = address;
                                    store_district = district;
                                    store_postal_code = postal_code;
                                    store_phone_number = phone;
                                    store_city = city;
                                    store_country = country;
                                    store_manager_staff_id = manager_staff_id;
                                    store_manager_first_name = first_name;
                                    store_manager_last_name = last_name;

                                    SimpleDateFormat sdf3 = new SimpleDateFormat("yyyy-MM-dd");
                                    store_valid_from = null;
                                    store_valid_through = null;
                                    try {
                                        java.util.Date store_valid_from1 = sdf3.parse("1900-01-01");
                                        java.util.Date store_valid_through1 = sdf3.parse("2200-01-01");
                                        store_valid_from = new java.sql.Timestamp(store_valid_from1.getTime());
                                        store_valid_through = new java.sql.Timestamp(store_valid_through1.getTime());
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }

                                    System.out.println("处理数据成功！");

                                    sql7 = "INSERT INTO dim_store " +
                                            " values('"+ store_key++ +"','"+ store_last_update +"','"+ store_id +"','"+ store_addrees +"','"+
                                            store_district +"','" + store_postal_code + "','" + store_phone_number + "','" +store_city+ "','" +store_country+ "','"+
                                            store_manager_staff_id+ "','" +store_manager_first_name+ "','" +store_manager_last_name+ "','" +store_version_number+ "','"+
                                            store_valid_from+"','"+store_valid_through+"')";

                                    stmt7.executeUpdate(sql7);

                                    System.out.println("插入数据成功！");
                                }
                            }
                        }
                    }
                }
            }
            stmt1.close();
            stmt2.close();
            stmt3.close();
            stmt4.close();
            stmt5.close();
            stmt6.close();
            stmt7.close();
            dbConn1.close();
            dbConn2.close();
        }
        catch (ClassNotFoundException e) {
            e.printStackTrace(); }
        catch (SQLException e) {
            e.printStackTrace(); }
    }
}
